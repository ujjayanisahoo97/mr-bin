
<footer class="container-fluid nopadding" id="footer"><!--Footer-->
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-6 copy" >
						<p>Copyright © 2018 MR. BIN Org. All rights reserved.</p>
					</div>
					<div class="col-md-6">
						<p class="text-right">Connect with us</p>
						<ul class="list-inline text-right">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
</footer><!--/Footer-->
	
	